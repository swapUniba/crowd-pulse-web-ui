(function() {
  'use strict';

  angular
    .module('webUi')
    .constant('toolbarLoadedEvent', 'toolbar:loaded')
    .constant('toolbarLoadingEvent', 'toolbar:loading');

})();
