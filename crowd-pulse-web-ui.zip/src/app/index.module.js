(function() {
  'use strict';
  angular
    .module('webUi',
    ['ngAnimate', 'ngCookies', 'ngTouch', 'ngSanitize', 'restangular', 'ui.router', 'ngMaterial',
     'ui.ace', 'btford.socket-io', 'angular-jqcloud', 'frapontillo.highcharts', 'angular.filter','satellizer','leaflet-directive']);


})();
