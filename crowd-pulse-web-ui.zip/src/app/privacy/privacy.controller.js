(function() {
  'use strict';

  angular.module('webUi')
    .controller('PrivacyController', PrivacyController);

  /** @ngInject */
  function PrivacyController() {
    var vm = this;
  }

})();
